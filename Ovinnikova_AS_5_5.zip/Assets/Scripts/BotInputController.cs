﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Cars
{

    public class BotInputController : BaseInputController
    {
        protected override void FixedUpdate()
        {
            throw new System.NotImplementedException();
        }
    }
}
